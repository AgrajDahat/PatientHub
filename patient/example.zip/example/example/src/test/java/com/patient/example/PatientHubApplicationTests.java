package com.patient.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
